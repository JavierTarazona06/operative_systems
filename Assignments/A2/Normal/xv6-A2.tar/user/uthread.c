#include "../kernel/types.h"
#include "../kernel/stat.h"
#include "user.h"

/* CMPT 332 GROUP 63 Change, fall 2024 */
#include <stdatomic.h>
#include <stdint.h>

/* Possible states of a thread: */
#define FREE        0x0
#define RUNNING     0x1
#define RUNNABLE    0x2

#define STACK_SIZE  8192
#define MAX_THREAD  4

/* CMPT 332 GROUP 63 Change, fall 2024 */
volatile int a_started, 
b_started, 
c_started;

volatile int a_n, 
b_n, 
c_n;

/* CMPT 332 GROUP 63 Change, fall 2024 */
typedef struct {
  atomic_int isLocked;
} Mutex;
Mutex mutexArray[1000];

/* CMPT 332 GROUP 63 Change, fall 2024 */
typedef struct {
	uint64_t ra;  // address
	uint64_t sp;  // stack pointer
	uint64_t s0;  // frame pointer
} thread_context;

struct thread {
  char       stack[STACK_SIZE]; /* the thread's stack */
  /* CMPT 332 GROUP 63 Change, fall 2024 */
  int        state;             /* FREE, RUNNING, RUNNABLE */
  thread_context *context;
};
struct thread all_thread[MAX_THREAD];
struct thread *current_thread;

/* CMPT 332 GROUP 63 Change, fall 2024 */
extern void thread_switch(thread_context_t *old_context, 
thread_context_t *new_context);
/*extern void thread_switch(uint64, uint64);*/

/* CMPT 332 GROUP 63 Change, fall 2024 */
/*
Creates a new mutex initialized with "locked".
*/
int mtx_create(int locked) {
  static atomic_int next_id = 0;
  int id = atomic_fetch_add(&next_id, 1);
  mutexArray[id].isLocked = locked;
  return id;
}

/* CMPT 332 GROUP 63 Change, fall 2024 */
/*
This implements P()
Currently it just spins while it waits for a V().
*/
int mtx_lock(int lock_id) {
  while (atomic_exchange(&mutexArray[lock_id].isLocked, 1)) { ; }
  return 0;
}

/* CMPT 332 GROUP 63 Change, fall 2024 */
/*
This implements V()
*/
int mtx_unlock(int lock_id) {
  atomic_store(&mutexArray[lock_id].isLocked, 0);
  return 0;
}

void 
thread_init(void)
{
  // main() is thread 0, which will make the first invocation to
  // thread_schedule().  it needs a stack so that the 
  //first thread_switch() can
  // save thread 0's state.  thread_schedule() won't run the main 
  // thruint64_thread ever
  // again, because its state is set to RUNNING, and 
  // thread_schedule() selects
  // a RUNNABLE thread.

  current_thread = &all_thread[0];
  current_thread->state = RUNNING;
}

void 
thread_schedule(void)
{
  struct thread *t, *next_thread;

  /* Find another runnable thread. */
  next_thread = 0;
  t = current_thread + 1;
  for(int i = 0; i < MAX_THREAD; i++){
    if(t >= all_thread + MAX_THREAD)
      t = all_thread;
    if(t->state == RUNNABLE) {
      next_thread = t;
      break;
    }
    t = t + 1;
  }

  if (next_thread == 0) {
    printf("thread_schedule: no runnable threads\n");
    exit(-1);
  }

  if (current_thread != next_thread) {         /* switch threads?  */
    /*The thread is runnable, so we can put it to run. Do 
     * a context switch to this thread*/
    next_thread->state = RUNNING;
    t = current_thread;
    current_thread = next_thread;
      /* YOUR CODE HERE
      * Invoke thread_switch to switch from t to next_thread:
      * thread_switch(??, ??);
      */
      current_thread->state = RUNNABLE;
      next_thread->state = RUNNING;
      thread_switch(current_thread->context, next_thread->context);
      next_thread->stack = next_thread->context->s0;
  } else
    next_thread = 0;
}

void 
thread_create(void (*func)())
{
  /* The thread will have a context 
  (r.a= return address), sp, s0 */
  struct thread *t;
  struct context *context_th;


  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
    if (t->state == FREE) break;
  }
  t->state = RUNNABLE;
  // YOUR CODE HERE
  /* CMPT 332 GROUP 63 Change, fall 2024 */
  
  context_th->ra = (uint64_t)func;
  context_th->sp = (uint64_t)0;
  context_th->s0 = (uint64_t)t-> stack;
  t->context = context_th;

  t-> stack[t->context->sp] = *(char *)func;
  t->context->sp = sizeof(func) + t->context->sp;

}

void 
thread_yield(void)
{
  current_thread->state = RUNNABLE;
  thread_schedule();
}



void 
thread_a(void)
{
  int i;
  /* CMPT 332 GROUP 63 Change, fall 2024 */
  int mutexa = mtx_create(1);

  printf("thread_a started\n");
  a_started = 1;
  while(b_started == 0 || c_started == 0)
    thread_yield();
  
  for (i = 0; i < 100; i++) {

    /* CMPT 332 GROUP 63 Change, fall 2024 */
    mtx_lock(mutexa);
    printf("thread_a %d\n", i);
    a_n += 1;
    mtx_unlock(mutexa);

    thread_yield();
  }
  printf("thread_a: exit after %d\n", a_n);

  current_thread->state = FREE;
  thread_schedule();
}

void 
thread_b(void)
{
  int i;
  /* CMPT 332 GROUP 63 Change, fall 2024 */
  int mutexb = mtx_create(1);

  printf("thread_b started\n");
  b_started = 1;
  while(a_started == 0 || c_started == 0)
    thread_yield();
  
  for (i = 0; i < 100; i++) {
    
    /* CMPT 332 GROUP 63 Change, fall 2024 */
    mtx_lock(mutexb);
    printf("thread_b %d\n", i);
    b_n += 1;
    mtx_unlock(mutexb);

    thread_yield();
  }
  printf("thread_b: exit after %d\n", b_n);

  current_thread->state = FREE;
  thread_schedule();
}

void 
thread_c(void)
{
  int i;
  /* CMPT 332 GROUP 63 Change, fall 2024 */
  int mutexc = mtx_create(1);

  printf("thread_c started\n");
  c_started = 1;
  while(a_started == 0 || b_started == 0)
    thread_yield();
  
  for (i = 0; i < 100; i++) {

    /* CMPT 332 GROUP 63 Change, fall 2024 */
    mtx_lock(mutexc);
    printf("thread_c %d\n", i);
    c_n += 1;
    mtx_unlock(mutexc);

    thread_yield();
  }
  printf("thread_c: exit after %d\n", c_n);

  current_thread->state = FREE;
  thread_schedule();
}

int 
main(int argc, char *argv[]) 
{
  a_started = b_started = c_started = 0;
  a_n = b_n = c_n = 0;
  thread_init();
  thread_create(thread_a);
  thread_create(thread_b);
  thread_create(thread_c);
  thread_schedule();
  exit(0);
}
