/* Physical memory allocator, for user processes, */
/* kernel stacks, page-table pages, */
/* and pipe buffers. Allocates whole 4096-byte pages. */

#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "riscv.h"
#include "defs.h"

extern char end[]; /* first address after kernel. */
                   /* defined by kernel.ld. */

/* CMPT 332 GROUP 63 Change, Fall 2024 */
int page_ref_counts[TOTAL_NUM_PAGES];

void freerange(void *pa_start, void *pa_end);



struct run {
  struct run *next;
};
struct spinlock refCountLock;

struct {
  struct spinlock lock;
  struct run *freelist;
  /* CMPT 332 GROUP 63 Change, Fall 2024 */
  int numFreePages;
} kmem;

/* CMPT 332 GROUP 63 Change, Fall 2024 */
/*int get_page_index(void *page_address) {
  uint64 pa = (uint64)page_address;
  uint64 base = (uint64)end;

  if (pa < base || pa >= base + (TOTAL_NUM_PAGES * PGSIZE)) {
    panic("Get_Page_Index: invalid page address given");
  }

  return pa / PGSIZE;
}*/

/* CMPT 332 GROUP 63 Change, Fall 2024 */
int get_page_index(void *page_address) {
  int result = ((uint64)page_address - (uint64)end)/ PGSIZE;

  return result;
}
/* CMPT 332 GROUP 63 Change, Fall 2024 */
int get_page_index_uint(uint64 page_address) {
    int result = (page_address - (uint64)end)/ PGSIZE;
    return result;
}

/* CMPT 332 GROUP 63 Change, Fall 2024 */
void increase_cow_reference(uint64 page_address){
    acquire(&refCountLock);
    int refCountIndex;
    refCountIndex = get_page_index_uint(page_address);
    if (refCountIndex < 0 || refCountIndex >= TOTAL_NUM_PAGES) {
        release(&refCountLock);
        panic("refCountIndex out of bounds");
    }
    page_ref_counts[refCountIndex]++;
    release(&refCountLock);
}

/* CMPT 332 GROUP 63 Change, Fall 2024 */
void decrease_cow_reference(uint64 page_address){
    
    /*printf("page_address: %p\n", page_address);*/
    
    acquire(&refCountLock);
    int refCountIndex;
    refCountIndex = get_page_index_uint(page_address);
    if (refCountIndex < 0 || refCountIndex >= TOTAL_NUM_PAGES) {
        release(&refCountLock);
        panic("refCountIndex out of bounds");
    }
    page_ref_counts[refCountIndex]--;
    release(&refCountLock);
}


void
kinit()
{
  initlock(&kmem.lock, "kmem");
  initlock(&refCountLock, "page_ref_counts");
  /* CMPT 332 GROUP 63 Change, Fall 2024 */
  kmem.numFreePages = 0;
  
  /* CMPT 332 GROUP 63 Change, Fall 2024 */
  for (int i = 0; i < TOTAL_NUM_PAGES; i++) {
    page_ref_counts[i] = 1;
  }
  
  
  freerange(end, (void*)PHYSTOP);  
}

void
freerange(void *pa_start, void *pa_end)
{
  char *p;
  p = (char*)PGROUNDUP((uint64)pa_start);
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    kfree(p);
}

/* Free the page of physical memory pointed at by pa, */
/* which normally should have been returned by a */
/* call to kalloc().  (The exception is when */
/* initializing the allocator; see kinit above.) */
void
kfree(void *pa)
{
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    panic("kfree");

  /* Fill with junk to catch dangling refs. */
  memset(pa, 1, PGSIZE);

  r = (struct run*)pa;


  acquire(&kmem.lock);
  acquire(&refCountLock);
  
  /* CMPT 332 GROUP 63 Change, Fall 2024 */
  
  int index = get_page_index(pa);

  /* Is in user space  */
  if (((uint64)pa >= KERNBASE) && ((uint64)pa <= PHYSTOP)){
    if (page_ref_counts[index] <= 0) { panic("kfree: Page refrence count dropped below 0");}
    if (--page_ref_counts[index] == 0) {
      r->next = kmem.freelist;
      kmem.freelist = r;
      kmem.numFreePages++;
    }
  } else {
      r->next = kmem.freelist;
      kmem.freelist = r;
  }

  release(&refCountLock);
  release(&kmem.lock);

}

/* Allocate one 4096-byte page of physical memory. */
/* Returns a pointer that the kernel can use. */
/* Returns 0 if the memory cannot be allocated. */
void *
kalloc(void)
{
  struct run *r;

  acquire(&kmem.lock);
  acquire(&refCountLock);
  r = kmem.freelist;
  if(r) {
    /* CMPT 332 GROUP 63 Change, Fall 2024 */
    kmem.numFreePages--;
    int index = get_page_index(r);
    page_ref_counts[index] = 1;
  
    kmem.freelist = r->next;
  }
  release(&refCountLock);
  release(&kmem.lock);
  

  if(r)
    memset((char*)r, 5, PGSIZE); /* fill with junk */
  return (void*)r;
}
