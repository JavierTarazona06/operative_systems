/* Anish Bhagat, Rudra Patel
11337909, 11336356
cyn482, cvb652 */

#include "kernel/types.h"
#include "user/user.h"
#define NUM_CHILDRENS 10

int square(int number){
    if (number == 0){
        return 0;
    }
    return square(number - 1) + number + number - 1;
}

int mainp(void){
    int pid;
    int index;
    int random_sleeptime;
    int random_number;
    for(index=0;index<NUM_CHILDRENS;index++){
        pid = fork();
        if(pid < 0){
            exit(1);
        }
        if(pid == 0){
            printf("Process %d got created with CPU share %d\n",getpid(),get_share());
            printf("Process %d started job with share %d \n",getpid(),get_share());
            random_sleeptime = rand() % 100;
            sleep(random_sleeptime);
            random_number = rand() % 100;
            square(random_number);
            printf("Process %d finished the square execution with share %d\n",getpid(),get_share());
            exit(0);
        }
        sleep(3);
    }

    while(wait(0) > 0)
    printf("Fair share scheduler test completed \n");
    exit(0);
    return 0;
}
