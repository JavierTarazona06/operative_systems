/* NAME: Javier Andres Tarazona Jimenez, Steven Baldwin
   NSID: elr490, sjb956
   Student Number: 11411898, 11300210
   CMPT 332 Term 1 2024
   Assignment 3
*/
/* CMPT 332 GROUP 63 Change, Fall 2024 */

#include "kernel/types.h"
#include "kernel/stat.h"
#include "user.h"

#define NUM_PROCESSES 4
#define TIME_MAX 10
#define SQUARE_COMP_MAX 20
#define MAX_SHARE 20
#define MAX_GROUP 4

my_mutex mutex_print;
int times[NUM_PROCESSES];
int start_time;


/* Time max is in seconds*/

/* We have shares from 1 to 20 and groups from 1 to 4 */
/* Share is 1 lowest priority, 10 is normal and 20 is high priority*/
/* Group Default is 2. 1 is for background task. 3 and 4 are more priority */

int square(int n, int i){
    /*mutex_lock(&mutex_print);
    printf("Process %d is computing square", i);
    mutex_unlock(&mutex_print);*/

    if (n==0){
        return 0;
    } else {
        return square(n-1, i) + n + n - 1;
    }
}


int main() {
    int pid, i, j;
    int time_sleep, this_share, this_group, compute_square;

    mutex_init(&mutex_print);

    printf("Parent process created\n");
    start_time = uptime();
    printf("Start time is: %d\n", start_time);

    for (i = 0; i < NUM_PROCESSES; i++){
        pid = fork();
        if (pid < 0) {
            printf("Fork failed\n");
            exit(0);
        }

        /*This is for the children - Children execution*/
        if (pid == 0) {
            times[i] = uptime();

            this_share = (user_rand(uptime())) % (MAX_SHARE+1);
            this_group = (user_rand(uptime())) % (MAX_GROUP+1);

            if (this_share == 0){this_share = 1;}
            if (this_group == 0){this_group = 1;}
            setshare(this_share);
            setgroup(this_group);

            mutex_lock(&mutex_print);
            printf("Process %d started with share %d and group %d.\n",
                   i, this_share, this_group);
            mutex_unlock(&mutex_print);

            time_sleep = (user_rand(uptime())) %TIME_MAX;

            mutex_lock(&mutex_print);
            printf("Process %d to sleep %d seconds.\n", i, time_sleep);
            mutex_unlock(&mutex_print);

            sleep(time_sleep);

            mutex_lock(&mutex_print);
            printf("Process %d has woken up\n", i);
            mutex_unlock(&mutex_print);

            compute_square = (user_rand(uptime())) % SQUARE_COMP_MAX;

            mutex_lock(&mutex_print);
            printf("Process %d is going to compute square %d times\n",
                   i, compute_square);
            mutex_unlock(&mutex_print);

            for (j=0; j < compute_square; j++){
                square(user_rand(uptime())%SQUARE_COMP_MAX, i);
            }

            times[i] = uptime()-times[i];
            printf("Runtime of process %d is %d\n", i, times[i]);
            exit(0);
        }
        sleep(10);
    }

    for (i = 0; i < NUM_PROCESSES; i++) {
        wait(0);
    }

    printf("All processes have finished\n");
    exit(0);
}