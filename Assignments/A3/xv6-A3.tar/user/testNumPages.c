#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

/* CMPT 332 GROUP XX Change, Fall 2024 */
int
main()
{
    int numPages;
    numPages = getNumFreePages();
    printf("numPages: %d\n", numPages);
    exit(0);
}