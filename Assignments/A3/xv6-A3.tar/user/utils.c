#include "kernel/types.h"
#include "kernel/stat.h"
#include "user.h"
#include "kernel/param.h"

/* from FreeBSD. */
int
do_rand1(unsigned long *ctx)
{
/*
 * Compute x = (7^5 * x) mod (2^31 - 1)
 * without overflowing 31 bits:
 *      (2^31 - 1) = 127773 * (7^5) + 2836
 * From "Random number generators: good ones are hard to find",
 * Park and Miller, Communications of the ACM, vol. 31, no. 10,
 * October 1988, p. 1195.
 */
    long hi, lo, x;

    /* Transform to [1, 0x7ffffffe] range. */
    x = (*ctx % 0x7ffffffe) + 1;
    hi = x / 127773;
    lo = x % 127773;
    x = 16807 * lo - 2836 * hi;
    if (x < 0)
        x += 0x7fffffff;
    /* Transform to [0, 0x7ffffffd] range. */
    x--;
    *ctx = x;
    return (x);
}


int
user_rand(int seed)
{
    unsigned long rand_next = seed;
    return (do_rand1(&rand_next));
}

void mutex_init(my_mutex *m){
    m->locked = 0;
}
void mutex_lock(my_mutex *m){
    while (__sync_lock_test_and_set(&m->locked, 1)) {
        sleep(1);
    }
}
void mutex_unlock(my_mutex *m){
    __sync_lock_release(&m->locked);
}