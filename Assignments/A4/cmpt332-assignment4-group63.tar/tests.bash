#!/bin/bash


#./PartASim 40 8 24 0 5 20 "test-output.txt"
#./PartASim 64 8 24 0 5 20 "test-output.txt"
#./PartASim 256 8 24 0 5 20 "test-output.txt"

#./PartASim 40 8 24 1 5 20 "test-output.txt"
#./PartASim 64 8 24 1 5 20 "test-output.txt"
#./PartASim 256 8 24 1 5 20 "test-output.txt"



#./PartASim 64 4 24 0 5 20 "test-output.txt"
#./PartASim 64 8 24 0 5 20 "test-output.txt"
#./PartASim 64 32 24 0 5 20 "test-output.txt"

#./PartASim 64 4 24 1 5 20 "test-output.txt"
#./PartASim 64 8 24 1 5 20 "test-output.txt"
#./PartASim 64 32 24 1 5 20 "test-output.txt"



./PartASim 64 8 16 0 5 20 "test-output.txt"
./PartASim 64 8 24 0 5 20 "test-output.txt"
./PartASim 64 8 32 0 5 20 "test-output.txt"

./PartASim 64 8 16 1 5 20 "test-output.txt"
./PartASim 64 8 24 1 5 20 "test-output.txt"
./PartASim 64 8 32 1 5 20 "test-output.txt"

