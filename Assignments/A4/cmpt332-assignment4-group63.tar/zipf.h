/*
NAMEs: Javier Andres Tarazona Jimenez, Steven Baldwin
NSIDs: elr490, sjb956
Student Numbers: 11411898, 11300210
*/

double get_virtual_normalization_constant();
unsigned int zipf_virtual_address(double C);