/* string input routines
 * @author: Kernighan/Ritchie
 * @date: 1978
 */
 
/* NAME: Javier Andres Tarazona Jimenez
   NSID: elr490
   Student Number: 11411898

   CMPT 332 Term 1 2024

   Lab 0
*/


#include <qsort.h>

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAXLEN 100

int myGetline(char s[], int lim)
{
  int c, i;

  for (i=0;i<lim-1 && (c=getchar()) != EOF && c!='\n'; ++i)
    s[i] = c;
  if (c == '\n')
    {
      s[i] = c;
      ++i;
    }
    s[i] = '\0';
  return i;
  
}


int readlines(char *lineptr[], int maxlines)
{
  int len, nlines;
  char *p, line[MAXLEN];

  nlines=0;
  while ((len = myGetline(line, MAXLEN)) > 1)
    {
      if (nlines >= maxlines || (p = (char *)malloc(len+1)) == NULL)
	return -1;
      else 
	{
	  line [len-1] = '\0';
	  strcpy(p, line); /*Allocating mem.*/
	  lineptr[nlines++] = p;
	}
    }
  
  return nlines;
}

void writelines(char *lineptr[], int nlines)
{
  while (nlines-- >0)
    printf("%s\n", *lineptr++);
}
