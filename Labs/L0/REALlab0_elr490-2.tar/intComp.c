/* intComp.c
 * Implementation of comparison function
 * @author Dwight Makaroff
 * @date: July 2023
 */
 
 /* NAME: Javier Andres Tarazona Jimenez
   NSID: elr490
   Student Number: 11411898

   CMPT 332 Term 1 2024

   Lab 0
*/


#include <qsort.h>
/* returns -1 if first < second
 * returns 0 if first == second
 * returns 1 if first > second
 */

#include <stdio.h>
#include <stdlib.h>


int compareInt(void *first, void *second)
{
	char *end;
	char *strFirst = (char*)first;
	char *strSecond = (char*)second;
	
	long int liFirst = strtol(strFirst, &end, 10);
	long int liSecond = strtol(strSecond, &end, 10);

	if (liFirst < liSecond){
		return -1;
	} else if (liFirst > liSecond) {
		return 1;
	} else {
		return 0;
	}
}


