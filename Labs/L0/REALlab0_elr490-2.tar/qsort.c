
/* @author Kernighan/Ritchie
 * @modified by: Dwight Makaroff
 * @date: July 2023
 * @purpose: review of CMPT 214 programming style and
 * debugging skills
 */
/*
 * qsort: sort v[left]...v[right] into increasing order.

 * The array v is void *, but from the calling program we see that
 * these are strings.
 */
 
 /* NAME: Javier Andres Tarazona Jimenez
   NSID: elr490
   Student Number: 11411898

   CMPT 332 Term 1 2024

   Lab 0
*/


#include <qsort.h>

void myQsort(void *v[], int left, int right, Comparator comp)
{
    int index, last;
    last = left-1;

    if (left >= right)  
        return;

    for (index = left; index <= right; index++){
		if ((*comp)(v[index],v[right]) < 0){
			last++;
			(swap)(v, last, index);
		}
	}
	       
	(swap)(v, last+1, right);
	last++;
	
    myQsort(v, left, last-1, comp);
    myQsort(v, last+1, right, comp);
}
