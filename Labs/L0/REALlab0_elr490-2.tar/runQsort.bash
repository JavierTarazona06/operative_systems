# NAME: Javier Andres Tarazona Jimenez
#   NSID: elr490
#   Student Number: 11411898

#   CMPT 332 Term 1 2024

#   Lab 0


#!/bin/bash
echo $1 $2

./myQsort $1 < $2
