/* intComp.cd
 * Implementation of comparison function
 * @author Dwight Makaroff
 * @date: July 2023
 */
#include "qsort.h"
#include <stdio.h>
#include <stdlib.h>

/* returns -1 if first < second
 * returns 0 if first == second
 * returns 1 if first > second
 */
 
 
int compareDouble(void* first, void* second)
{
	char *end;
	char *strFirst = (char*)first;
	char *strSecond = (char*)second;
	
	double dFirst = strtod(strFirst, &end);
	double dSecond = strtod(strSecond, &end);
	
	if (dFirst < dSecond) {
		return -1;
	} else if (dFirst > dSecond) {
		return 1;
	} else {
		return 0;
	}
}


