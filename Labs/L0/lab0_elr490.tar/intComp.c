/* intComp.c
 * Implementation of comparison function
 * @author Dwight Makaroff
 * @date: July 2023
 */

#include "qsort.h"
/* returns -1 if first < second
 * returns 0 if first == second
 * returns 1 if first > second
 */

#include <stdio.h>
#include <stdlib.h>


int compareInt(void *first, void *second)
{
	char *end;
	char *strFirst = (char*)first;
	char *strSecond = (char*)second;
	
	long int liFirst = strtol(strFirst, &end, 10);
	long int liSecond = strtol(strSecond, &end, 10);
	int iFirst = (int) liFirst;
	int iSecond = (int) liSecond;

	if (iFirst < iSecond){
		return -1;
	} else if (iFirst > iSecond) {
		return 1;
	} else {
		return 0;
	}
}


