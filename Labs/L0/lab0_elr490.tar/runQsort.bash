#!/bin/bash
echo $1 $2

./myQsort $1 < $2
