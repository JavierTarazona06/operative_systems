# Tianze Kuang, wde364, 11352826
#!/bin/bash

rg '.{81,}' -g '!.git'
echo "Done"