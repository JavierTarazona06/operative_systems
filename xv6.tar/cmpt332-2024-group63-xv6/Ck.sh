# Tianze Kuang, wde364, 11352826
#!/bin/bash

rg '.{80,}'
echo "Done"
